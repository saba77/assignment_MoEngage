import requests
from bs4 import BeautifulSoup
import openai
import json
from readability import Readability

class DocumentationAnalyzer:
    def __init__(self):
        self.style_guidelines = {
            "voice_and_tone": "Customer-focused, clear, and concise",
            "clarity": "Avoid overly complex sentences or jargon",
            "action_oriented": "Use action verbs to guide the user"
        }
    
    def fetch_article_content(self, url):
        try:
            response = requests.get(url)
            soup = BeautifulSoup(response.text, 'html.parser')
            article_content = soup.find('article') or soup.find('div', class_='article-content')
            
            for element in article_content(['script', 'style', 'nav', 'footer', 'header']):
                element.decompose()
                
            return article_content.get_text(separator='\n', strip=True)
        except Exception as e:
            return None
    
    def analyze_readability(self, text):
        results = {}
        r = Readability(text)
        results['flesch_kincaid'] = r.flesch_kincaid().score
        results['gunning_fog'] = r.gunning_fog().score
        
        prompt = f"Assess this documentation for a marketer:\n{text[:3000]}\n\nProvide:\n1. Brief assessment\n2. Specific hard-to-read sections\n3. Suggested improvements"
        results['marketer_assessment'] = self.query_llm(prompt)
        return results
    
    def analyze_structure(self, text):
        prompt = f"Analyze structure and flow:\n{text[:3000]}\n\nConsider:\n1. Headings\n2. Paragraph length\n3. Lists\n4. Logical flow"
        return self.query_llm(prompt)
    
    def analyze_completeness(self, text):
        prompt = f"Evaluate completeness:\n{text[:3000]}\n\nAssess:\n1. Implementation detail\n2. Example quality\n3. Information gaps"
        return self.query_llm(prompt)
    
    def analyze_style(self, text):
        prompt = f"Evaluate against style guidelines:\n{self.style_guidelines}\n\nText:\n{text[:3000]}\n\nAssess compliance and suggest improvements"
        return self.query_llm(prompt)
    
    def query_llm(self, prompt):
        try:
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "You are a documentation quality expert."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3
            )
            return response.choices[0].message.content
        except:
            return "Analysis unavailable"
    
    def analyze(self, url):
        text = self.fetch_article_content(url)
        if not text:
            return {"error": "Could not fetch content"}
        
        return {
            "url": url,
            "readability": self.analyze_readability(text),
            "structure": self.analyze_structure(text),
            "completeness": self.analyze_completeness(text),
            "style": self.analyze_style(text)
        }

if __name__ == "__main__":
    analyzer = DocumentationAnalyzer()
    url = input("Enter MoEngage documentation URL: ")
    results = analyzer.analyze(url)
    
    print("\nAnalysis Results:")
    print(json.dumps(results, indent=2))
    
    with open("analysis_results.json", "w") as f:
        json.dump(results, f, indent=2)