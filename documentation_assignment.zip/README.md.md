# Documentation Improvement Agent

## Setup
1. Install dependencies: `pip install -r requirements.txt`
2. Set OpenAI API key: `export OPENAI_API_KEY='your_key'`

## Usage
Run: `python agent.py` and enter a MoEngage docs URL

## Features
- Readability analysis (Flesch-Kincaid, Gunning Fog)
- Structure and flow evaluation
- Completeness assessment
- Style guideline compliance

## Example Outputs
See examples/ folder for sample analyses of:
1. Getting Started guide
2. Campaign creation article

## Design
- Hybrid approach combining traditional metrics and LLM analysis
- Modular components for each analysis type
- Actionable, specific suggestions